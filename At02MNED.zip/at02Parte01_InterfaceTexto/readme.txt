MNEDOPVI

Trabalho realizado por:
    -> Alexandre Reis       - 21289026
    -> Celso Jordão         - 21130067
    -> Fábio Capobianchi    - 21280924

Para executar a gui é necessário correr o ficheiro GUI.m

Na pasta relatório, estão localizados 3 ficheiros com o relatório em formatos diferentes (.docx, .odt, .pdf)

Na pasta interfaces de teste, estão alguns ficheiros que usamos para testar algumas funções.

